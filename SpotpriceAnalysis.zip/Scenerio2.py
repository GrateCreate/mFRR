# -*- coding: utf-8 -*-
import csv
filename=open('spotpriser.csv','r')
data = csv.DictReader(filename)

NO2=[]      #Sør
NO3=[]      #Midt

for col in data:
    NO2.append(col['NO2'])
    NO3.append(col['NO3'])
    
NO2=list(map(float,NO2)) #Mapping strings to floats
NO3=list(map(float,NO3))

PriceListNO2Sc2=[]
PriceListNO3Sc2=[]

def averages(dayprices):
    averages=[]
    k=0
    while k+13 < 24: #creating 4 hour blocks every hour
        averages.append(sum(dayprices[k:k+14])) #Taking the 14-hour average and appending to list
        k+=1
    return averages #Return list of 21 average values

i=0
while i<len(NO2)/24:
    j=i+1
    daypricesNO2=NO2[i*24:(j*24)] #List of this days prices
    daypricesNO3=NO3[i*24:j*24]
    i+=1
    NO2average=averages(daypricesNO2)
    NO3average=averages(daypricesNO3)
    NO2average.sort()
    NO3average.sort()
    PriceListNO2Sc2.append(NO2average[0])
    PriceListNO3Sc2.append(NO3average[0])
