# -*- coding: utf-8 -*-
import csv
filename=open('spotpriser.csv','r')
data = csv.DictReader(filename)

NO2=[]      #Sør
NO3=[]      #Midt

for col in data:
    NO2.append(col['NO2'])
    NO3.append(col['NO3'])
    
NO2=list(map(float,NO2)) #Mapping strings to floats
NO3=list(map(float,NO3))

PriceListNO2Sc1=[]
PriceListNO3Sc1=[]
TimelistNO2, TimelistNO3=[0]*24,[0]*24
i=0
while i<len(NO2)/24:
    j=i+1
    daypricesNO2=NO2[i*24:(j*24)] #List of this days prices
    daypricesNO3=NO3[i*24:j*24]
    daypricesNO2wrap=daypricesNO2[11:24]+daypricesNO2[0:13:1]
    daypricesNO3wrap=daypricesNO3[11:24]+daypricesNO3[0:13:1]
    i+=1
    k=0
    DayNO2=0
    DayNO3=0
    
    while k < 24:
        if k < 11:
            TimelistNO2[k]+=sum(daypricesNO2[k:k+14])
            TimelistNO3[k]+=sum(daypricesNO3[k:k+14])
            k+=1
    
        else:
            TimelistNO2[k]+=sum(daypricesNO2wrap[k-11:k+3])
            TimelistNO3[k]+=sum(daypricesNO3wrap[k-11:k+3])
            k+=1
            
    PriceListNO2Sc1.append(sum(daypricesNO2[1:15]))
    PriceListNO3Sc1.append(sum(daypricesNO3wrap[7:21]))
print(TimelistNO2.index(min(TimelistNO2)),TimelistNO3.index(min(TimelistNO3)))
print(TimelistNO2[1],TimelistNO3[18]) #From 01-15 in NO2 and 18-08 in NO3
print(sum(PriceListNO3Sc1))
