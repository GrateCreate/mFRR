# -*- coding: utf-8 -*-

import csv
filename=open('spotpriser.csv','r')
data = csv.DictReader(filename)

#time=[]
#NO1=[]      #Øst
NO2=[]      #Sør
NO3=[]      #Midt
#NO4=[]      #Nord
#NO5=[]      #Vest
#Jeg skal se på sør-norge og trondheims regionen, 2 og 3
for col in data:#Reading the csv file into lists
    #time.append(col['DatoTid'])
    #NO1.append(col['NO1'])
    NO2.append(col['NO2'])
    NO3.append(col['NO3'])
    #NO4.append(col['NO4'])
    #NO5.append(col['NO5'])
NO2=list(map(float,NO2)) #Mapping strings to floats
NO3=list(map(float,NO3))

PriceListNO2Sc4=[]
PriceListNO3Sc4=[]

def averages(dayprices):
    averages=[]
    k=0
    while k+3 < 24: #creating 4 hour blocks every hour
        averages.append(sum(dayprices[k:k+4])/4) #Taking the 4-hour average and appending to list
        k+=1
    return averages #Return list of 21 average values
i=0
while i<len(NO2)/24:
    j=i+1
    daypricesNO2=NO2[i*24:(j*24)] #List of this days prices
    daypricesNO3=NO3[i*24:j*24]
    i+=1
    
    NO2average=averages(daypricesNO2) #Calling function to create 4 hour block averages and what numbers are used to make it
    NO2Sorted=sorted(NO2average) #sorted list from smallest to largest
    cheapBlocksNO2=[]
    cheapBlocksNO2.append(NO2Sorted[0]) #adding cheapest block to variable
    l=0
    for blocks in NO2Sorted:
        if abs(NO2average.index(blocks)-NO2average.index(cheapBlocksNO2[0]))>3: #Find the cheapeast block that is far enough away to not overlap
            cheapBlocksNO2.append(NO2Sorted[l]) #append this new cheapest block
            break
        else:
            l+=1
    removedNumbersNO2=[]
    for y in cheapBlocksNO2:
        position=NO2average.index(y)
        removedNumbersNO2+=daypricesNO2[position:position+4]
    for x in removedNumbersNO2:
        daypricesNO2.remove(x)
    daypricesNO2.sort()
    DaypriceNO2=sum(cheapBlocksNO2)*4+sum(daypricesNO2[0:6])
    PriceListNO2Sc4.append(DaypriceNO2)
    #####################################################################################
    NO3average=averages(daypricesNO3) #Calling function to create 4 hour block averages and what numbers are used to make it
    NO3Sorted=sorted(NO3average) #sorted list from smallest to largest
    cheapBlocksNO3=[]
    cheapBlocksNO3.append(NO3Sorted[0]) #adding cheapest block to variable
    k=0
    for blocks in NO3Sorted:
        if abs(NO3average.index(blocks)-NO3average.index(cheapBlocksNO3[0]))>3: #Find the cheapeast block that is far enough away to not overlap
            cheapBlocksNO3.append(NO3Sorted[k]) #append this new cheapest block
            break
        else:
            k+=1
    removedNumbersNO3=[]
    for z in cheapBlocksNO3:
        position=NO3average.index(z)
        removedNumbersNO3+=daypricesNO3[position:position+4]
    for p in removedNumbersNO3:
        daypricesNO3.remove(p)
    daypricesNO3.sort()
    DaypriceNO3=sum(cheapBlocksNO3)*4+sum(daypricesNO3[0:6])
    PriceListNO3Sc4.append(DaypriceNO3)
print(sum(PriceListNO2Sc4))
print(sum(PriceListNO3Sc4))