# -*- coding: utf-8 -*-
"""
Created on Wed Feb 21 13:26:13 2024

@author: early
"""

from entsoe import EntsoeRawClient
import pandas as pd

client = EntsoeRawClient(api_key='0e883dc0-dd01-4573-a7db-544cd5a2d994')

start = pd.Timestamp('20230101', tz='Europe/Brussels')
end = pd.Timestamp('20231231', tz='Europe/Brussels')
country_code = 'NO_3'  # Belgium
country_code_from = 'FR'  # France
country_code_to = 'DE_LU' # Germany-Luxembourg
type_marketagreement_type = 'A01'
contract_marketagreement_type = 'A01'
process_type = 'A47'#A47,52 56,60 ,61

#client.query_contracted_reserve_prices(country_code, start, end, type_marketagreement_type, psr_type=None)
#client.query_contracted_reserve_amount(country_code, start, end, type_marketagreement_type, psr_type=None)
#client.query_procured_balancing_capacity(country_code, start, end, process_type, type_marketagreement_type=None)

# xml_string = client.query_procured_balancing_capacity(country_code, start, end, process_type, type_marketagreement_type='A01')
# with open('outfile.xml', 'w') as f:
#     f.write(xml_string)

zip_bytes = client.query_procured_balancing_capacity(country_code, start, end, process_type, type_marketagreement_type=None)
with open('proc.zip', 'wb') as f:
    f.write(zip_bytes)