# -*- coding: utf-8 -*-
import csv
filename=open('spotpriser.csv','r')
data = csv.DictReader(filename)

NO2=[]      #Sør
NO3=[]      #Midt

for col in data:
    NO2.append(col['NO2'])
    NO3.append(col['NO3'])
    
NO2=list(map(float,NO2)) #Mapping strings to floats
NO3=list(map(float,NO3))

PriceListNO2Sc3=[]
PriceListNO3Sc3=[]

i=0
while i<len(NO2)/24:
    j=i+1
    daypricesNO2=NO2[i*24:(j*24)] #List of this days prices
    daypricesNO3=NO3[i*24:j*24]
    i+=1
    daypricesNO2.sort()
    daypricesNO3.sort()
    NO2price=0
    NO3price=0
    k=0
    while k<14:
        NO2price+=daypricesNO2[k]
        NO3price+=daypricesNO3[k]
        k+=1
    PriceListNO2Sc3.append(NO2price)
    PriceListNO3Sc3.append(NO3price)
