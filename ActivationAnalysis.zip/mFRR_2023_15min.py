# -*- coding: utf-8 -*-
import csv
#2023 Variables
OfferedUp_15min=[]
ActivatedUp_15min=[]
OfferedDown_15min=[]
ActivatedDown_15min=[]
PriceUp2023=[]
PriceDown2023=[]

#2024 Variables
OfferedUp_15min_2024=[]
ActivatedUp_15min_2024=[]
OfferedDown_15min_2024=[]
ActivatedDown_15min_2024=[]
PriceUp2024=[]
PriceDown2024=[]
#%% Reading and processing the mFRR file from 2023 fall to new year, 15 minute windows (ending with lists of 10660 timeslots)
 
with open('mFRR_bids_NO1_12_09_to_31_12_2023.csv',mode='r') as csv_file_15min: 
    read_15min=csv.reader(csv_file_15min,delimiter=",")
    next(read_15min)
    OfferedUp_15min_quoted=[]
    ActivatedUp_15min_quoted=[]
    OfferedDown_15min_quoted=[]
    ActivatedDown_15min_quoted=[]
    for row in read_15min:#Reading the csv file into lists
        data=(row[0].split(','))
        # print(data[4])
        if data[4]=='"Up"':
            OfferedUp_15min_quoted.append(data[5])
            ActivatedUp_15min_quoted.append(data[6])
        elif data[4]=='"Down"':
            OfferedDown_15min_quoted.append(data[5])
            ActivatedDown_15min_quoted.append(data[6])
        else:
            raise ValueError("ValueError in reading 15min file for 2023")
            
    OfferedUpstrip_15min=[s.strip('"') for s in OfferedUp_15min_quoted]         #Removing the "" from the strings
    ActivatedUpstrip_15min=[s.strip('"') for s in ActivatedUp_15min_quoted]
    ActivatedDownstrip_15min=[s.strip('"') for s in ActivatedDown_15min_quoted]
    OfferedDownstrip_15min=[s.strip('"') for s in OfferedDown_15min_quoted]
#%% Mapping string to float section 2023

for val in OfferedUpstrip_15min:                        #Mapping string to float
    try:
        if val =="":
            OfferedUp_15min.append(0)
        else:
            OfferedUp_15min.append(float(val))
    except ValueError:
        if val=="N/A":
            OfferedUp_15min.append(0)
        else:
            raise ValueError("Invalid value in list 1")
for val in ActivatedUpstrip_15min:
    try:
        if val =="":
            ActivatedUp_15min.append(0)
        else:
            ActivatedUp_15min.append(float(val))
    except ValueError:
        if val=="N/A":
            ActivatedUp_15min.append(0)
        else:
            raise ValueError("Invalid value in list 2")
for val in OfferedDownstrip_15min:
    try:
        if val =="":
            OfferedDown_15min.append(0)
        else:
            OfferedDown_15min.append(float(val))
    except ValueError:
        if val=="N/A":
            OfferedDown_15min.append(0)
        else:
            raise ValueError("Invalid value in list 3")
for val in ActivatedDownstrip_15min:
    try:
        if val =="":
            ActivatedDown_15min.append(0)
        else:
            ActivatedDown_15min.append(float(val))
    except ValueError:
        if val=="N/A":
            ActivatedDown_15min.append(0)
        else:
            raise ValueError("Invalid value in list 4")
del ActivatedDown_15min_quoted, ActivatedDownstrip_15min, ActivatedUp_15min_quoted, ActivatedUpstrip_15min

#%% Reading and processing of the mFRR file from 2024 new year to end of march, 15 minute window (ending with list of )

with open('mFRR_bids_NO1_01_01_to_12_04_2024.csv',mode='r') as csv_file_15min_2024: 
    read_15min_2024=csv.reader(csv_file_15min_2024,delimiter=",")
    next(read_15min_2024)
    OfferedUp_15min_2024_quoted=[]
    ActivatedUp_15min_2024_quoted=[]
    OfferedDown_15min_2024_quoted=[]
    ActivatedDown_15min_2024_quoted=[]
    for row in read_15min_2024:#Reading the csv file into lists
        data=(row[0].split(','))
        #print(data)
        if data[4]=='"Up"':
            OfferedUp_15min_2024_quoted.append(data[5])
            ActivatedUp_15min_2024_quoted.append(data[6])
        elif data[4]=='"Down"':
            OfferedDown_15min_2024_quoted.append(data[5])
            ActivatedDown_15min_2024_quoted.append(data[6])
        else:
            raise ValueError("ValueError in reading 15min file for 2024")
            
    OfferedUpstrip_15min_2024=[s.strip('"') for s in OfferedUp_15min_2024_quoted]         #Removing the "" from the strings
    ActivatedUpstrip_15min_2024=[s.strip('"') for s in ActivatedUp_15min_2024_quoted]
    ActivatedDownstrip_15min_2024=[s.strip('"') for s in ActivatedDown_15min_2024_quoted]
    OfferedDownstrip_15min_2024=[s.strip('"') for s in OfferedDown_15min_2024_quoted]

#%% Mapping strings to float section 2024
for val in OfferedUpstrip_15min_2024:  # Mapping string to float
    try:
        if val == "":
            OfferedUp_15min_2024.append(0)
        else:
            OfferedUp_15min_2024.append(float(val))
    except ValueError:
        if val == "N/A":
            OfferedUp_15min_2024.append(0)
        else:
            print(val)
            raise ValueError("Invalid value in list 1 2024")
for val in ActivatedUpstrip_15min_2024:
    try:
        if val == "":
            ActivatedUp_15min_2024.append(0)
        else:
            ActivatedUp_15min_2024.append(float(val))
    except ValueError:
        if val == "N/A":
            ActivatedUp_15min_2024.append(0)
        else:
            raise ValueError("Invalid value in list 2 2024")
for val in OfferedDownstrip_15min_2024:
    try:
        if val == "":
            OfferedDown_15min_2024.append(0)
        else:
            OfferedDown_15min_2024.append(float(val))
    except ValueError:
        if val == "N/A":
            OfferedDown_15min_2024.append(0)
        else:
            raise ValueError("Invalid value in list 3 2024")
for val in ActivatedDownstrip_15min_2024:
    try:
        if val == "":
            ActivatedDown_15min_2024.append(0)
        else:
            ActivatedDown_15min_2024.append(float(val))
    except ValueError:
        if val == "N/A":
            ActivatedDown_15min_2024.append(0)
        else:
            raise ValueError("Invalid value in list 4 2024")
del ActivatedDown_15min_2024_quoted, ActivatedDownstrip_15min_2024, ActivatedUp_15min_2024_quoted, ActivatedUpstrip_15min_2024

#%% Reading pricelist from 2023
with open('mFRR_NO1_balancing_prices_2023.csv',mode='r') as csv_file_15min_prices_2023:
    read_15min_price_2023=csv.reader(csv_file_15min_prices_2023,delimiter=",")
    next(read_15min_price_2023)
    for row in read_15min_price_2023:
        PriceUp2023.append(row[4])
        #RelevantPriceUp2023=PriceUp2023[6047:]
        PriceDown2023.append(row[5])
        #RelevantPriceDown2023=PriceDown2023[6047:]
    RelevantPriceDown2023=[float(val) for val in PriceDown2023[6047:]]
    RelevantPriceUp2023=[float(val) for val in PriceUp2023[6047:]]
#%% Reading pricelist from 2024
with open('mFRR_NO1_balancing_prices_2024.csv',mode='r') as csv_file_15min_prices_2024:
    read_15min_price_2024=csv.reader(csv_file_15min_prices_2024,delimiter=",")
    next(read_15min_price_2024)
    StripUp=[]
    StripDown=[]
    PriceUp2024Str=[]
    PriceDown2024Str=[]
    for row in read_15min_price_2024:
        data=(row[0].split(','))
        PriceUp2024Str.append(data[4])
        PriceDown2024Str.append(data[5])
    StripUp=[s.strip('"') for s in PriceUp2024Str] 
    StripDown=[s.strip('"') for s in PriceDown2024Str]
    for val in StripUp:#This part is necessary because the csv file was modified, and this impacts the readability of the file for some reason
        if val =='"0"':
            PriceUp2024.append(0)
        else:
            PriceUp2024.append(float(val))
    for val in StripDown:
        if val=='"0"':
            PriceDown2024.append(0)
        else:
            PriceDown2024.append(float(val))
        
#Lag summa sumarum for hvis det hadde vært en 1 MW IVF som skulle blitt aktivert,
def costActivation(Prices,Activated15min):
    result=[]
    map(float,Prices)
    for i in range(len(Prices)):
        for j in range(4):
            result.append(Activated15min[i*4+j]*Prices[i]*0.25)
    return result
ResultUp=costActivation(PriceUp2024,ActivatedUp_15min_2024)
ResultDown=costActivation(PriceDown2024, ActivatedDown_15min_2024)
#print(sum(ResultUp))
#print(sum(ResultDown))
def costActivation1MW(Prices,Activated15min):
    result=[]
    map(float,Prices)
    for i in range(len(Prices)):
        for j in range(4):
            if Activated15min[i*4+j]>0:
                result.append(Prices[i]*0.25)
            else:
                result.append(0)
                continue
    return result
def costActivation1MWUpOrDown(PricesUp, PricesDown,ActivatedUp15min,ActivatedDown15min):
    result=[]
    map(float,PricesUp)
    map(float,PricesDown)
    activationup=0
    activationdown=0
    for i in range(len(PricesUp)):
        for j in range(4):
            up_activated = ActivatedUp15min[i*4+j]>0
            down_activated = ActivatedDown15min[i*4+j]>0
            if up_activated and down_activated:
                if PricesUp[i]>=PricesDown[i]:
                    result.append(PricesUp[i]*0.25)
                    activationup=activationup+1
                else:
                    result.append(PricesDown[i]*0.25)
                    activationdown=activationdown+1
                continue    
            elif ActivatedUp15min[i*4+j]>0:
                result.append(PricesUp[i]*0.25)
                activationup=activationdown+1
                
            elif ActivatedDown15min[i*4+j]>0:
                result.append(PricesDown[i]*0.25)
                activationdown=activationdown+1
                
            else:
                result.append(0)
                
    return result,activationup,activationdown
ResultUp1MW=costActivation1MW(PriceUp2024,ActivatedUp_15min_2024)
ResultDown1MW=costActivation1MW(PriceDown2024, ActivatedDown_15min_2024)
Result1MW,activationup,activationdown=costActivation1MWUpOrDown(PriceUp2024, PriceDown2024, ActivatedUp_15min_2024, ActivatedDown_15min_2024)
print(sum(Result1MW),activationup,activationdown)
##Values used in the table in analysis section
print(sum(ResultUp1MW))
print(sum(ResultDown1MW))
#print(sum(OfferedUp_15min_2024)/4)
#print(sum(OfferedDown_15min_2024)/4)
#print(sum(ActivatedUp_15min_2024)/4)
#print(sum(ActivatedDown_15min_2024)/4)