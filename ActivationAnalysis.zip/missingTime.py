# -*- coding: utf-8 -*-
from datetime import datetime, timedelta
import csv
timestamps=[]

with open('mFRR_NO1_balancing_prices_2024.csv',mode='r') as csv_file_15min_prices_2024:
    read_15min_price_2024=csv.reader(csv_file_15min_prices_2024,delimiter=",")
    next(read_15min_price_2024)
    for row in read_15min_price_2024:
        timestamps.append(row[0][0:16])

# Convert strings to datetime objects
timestamps = [datetime.strptime(ts, '%d.%m.%Y %H:%M') for ts in timestamps]

# Sort the timestamps
timestamps.sort()

# Generate the expected timestamps
start_time = timestamps[0]
end_time = timestamps[-1]
current_time = start_time

expected_timestamps = []
while current_time <= end_time:
    expected_timestamps.append(current_time)
    current_time += timedelta(hours=1)

# Find missing timestamps
missing_timestamps = [ts for ts in expected_timestamps if ts not in timestamps]

# Print missing timestamps
missing_timestamps_str = [ts.strftime('%d.%m.%Y %H:%M') for ts in missing_timestamps]
print("Missing Timestamps:", missing_timestamps_str)